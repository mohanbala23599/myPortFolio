// header options
export const header_options = [
    {
        id : 1,
        link : "#",
        link_name : "services",
    },
    {
        id : 2,
        link : "#",
        link_name : "portfolio",
    },
    {
        id : 3,
        link : "#",
        link_name : "pricing"
    }
]

//introduction button name
export const button_name = {
    intro_bttn_name : "get started",
    carousel_bttn_name : "learn more"
}