import './App.css';
import PortfolioView from './views/portfolio-view/PortfolioView';

function App() {
  return (
    <div className="App">
      <PortfolioView></PortfolioView>
    </div>
  );
}

export default App;
